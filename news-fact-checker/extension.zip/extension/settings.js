// Settings page script for TruthPilot extension

// Configuration will be loaded from the extension context
let TruthPilotConfig = null;

// Environment detection function
async function detectEnvironment() {
  try {
    // Check if we can reach local development server
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2000); // 2 second timeout
    
    const response = await fetch('http://localhost:8000/health', {
      method: 'GET',
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);
    
    if (response.ok) {
      console.log('[settings.js] 🔧 Development environment detected (localhost:8000 available)');
      return false; // development
    }
  } catch (error) {
    // localhost not available, assume production
    console.log('[settings.js] 🚀 Production environment detected (localhost:8000 not available)');
  }
  
  return true; // production
}

// Load configuration
async function loadConfig() {
  if (window.TruthPilotConfig) {
    TruthPilotConfig = window.TruthPilotConfig;
    return TruthPilotConfig;
  }
  
  // Dynamic environment detection
  const isProduction = await detectEnvironment();
  
  // Fallback: inline config if not available globally
  TruthPilotConfig = {
    // Dynamically detected environment
    ENVIRONMENT: isProduction ? 'production' : 'development',
    
    // Environment-specific configurations
    environments: {
      development: {
        API_BASE_URL: 'http://localhost:8000',
        API_ENDPOINT: 'http://localhost:8000/analyze'
      },
      production: {
        API_BASE_URL: 'https://news-notes.onrender.com',
        API_ENDPOINT: 'https://news-notes.onrender.com/analyze'
      }
    },
    
    // Get current environment config
    get current() {
      return this.environments[this.ENVIRONMENT];
    },
    
    // Helper methods
    getApiUrl() {
      return this.current.API_ENDPOINT;
    },
    
    getBaseUrl() {
      return this.current.API_BASE_URL;
    },
    
    isDevelopment() {
      return this.ENVIRONMENT === 'development';
    },
    
    isProduction() {
      return this.ENVIRONMENT === 'production';
    }
  };
  
  // Make it available globally
  window.TruthPilotConfig = TruthPilotConfig;
  
  return TruthPilotConfig;
}

document.addEventListener('DOMContentLoaded', async () => {
  const closeBtn = document.getElementById('closeBtn');
  
  // Account status elements
  const accountStatus = document.getElementById('accountStatus');
  const accountPlan = document.getElementById('accountPlan');
  const accountUsage = document.getElementById('accountUsage');
  const manageAccountBtn = document.getElementById('manageAccountBtn');
  
  // Auto-analysis elements
  const autoAnalysisSettings = document.getElementById('autoAnalysisSettings');
  const autoAnalysisToggle = document.getElementById('autoAnalysisToggle');
  const autoAnalysisPreferences = document.getElementById('autoAnalysisPreferences');
  
  // Preference elements
  const analysisTrigger = document.getElementById('analysisTrigger');
  const analysisDepth = document.getElementById('analysisDepth');
  const showIndicator = document.getElementById('showIndicator');
  const autoOpenSidebar = document.getElementById('autoOpenSidebar');
  const quietMode = document.getElementById('quietMode');
  
  // General settings elements
  const enableShortcuts = document.getElementById('enableShortcuts');
  const enableNotifications = document.getElementById('enableNotifications');
  const themeSelect = document.getElementById('themeSelect');
  const cacheResults = document.getElementById('cacheResults');
  
  // Action buttons
  const clearCacheBtn = document.getElementById('clearCacheBtn');
  const reportIssueBtn = document.getElementById('reportIssueBtn');
  const contactSupportBtn = document.getElementById('contactSupportBtn');
  
  // Debug elements
  const debugPanel = document.getElementById('debugPanel');
  const debugInfo = document.getElementById('debugInfo');
  const testAutoAnalysis = document.getElementById('testAutoAnalysis');
  const versionInfo = document.getElementById('versionInfo');
  
  // Load configuration
  const config = await loadConfig();
  
  // Log current environment
  console.log(`TruthPilot settings running in ${config.ENVIRONMENT} mode`);
  console.log(`API URL: ${config.getApiUrl()}`);
  
  // Initialize settings page
  loadAccountStatus();
  setupAutoAnalysisSettings();
  setupGeneralSettings();
  setupActionButtons();
  loadVersionInfo();
  setupDebugPanel();
  
  // Close button handler
  closeBtn.addEventListener('click', () => {
    window.close();
  });
  
  // Manage account button handler
  manageAccountBtn.addEventListener('click', () => {
    // Open account management page in new tab
    chrome.tabs.create({ url: chrome.runtime.getURL('account.html') });
  });
  
  // Load and display account status
  async function loadAccountStatus() {
    try {
      const authToken = await new Promise(resolve => {
        chrome.storage.local.get(['authToken'], result => {
          resolve(result.authToken);
        });
      });
      
      if (!authToken) {
        // Show account status with sign-in prompt
        accountPlan.textContent = 'NOT SIGNED IN';
        accountPlan.className = 'plan-badge';
        accountUsage.textContent = 'Sign in to track usage';
        accountUsage.className = 'usage-text';
        accountStatus.style.display = 'block';
        autoAnalysisSettings.style.display = 'none';
        return;
      }
      
      // Get user usage information
      const response = await fetch(`${config.getBaseUrl()}/auth/usage`, {
        headers: {
          'Authorization': `Bearer ${authToken}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        if (response.status === 401) {
          // Clear invalid token
          chrome.storage.local.remove(['authToken']);
        }
        accountStatus.style.display = 'none';
        autoAnalysisSettings.style.display = 'none';
        return;
      }
      
      const usage = await response.json();
      
      // Update account status display
      accountPlan.textContent = usage.account_type.toUpperCase();
      accountPlan.className = `plan-badge ${usage.account_type}`;
      
      // Update usage display
      const usageLimit = usage.usage_limit === 999999 ? 'Unlimited' : usage.usage_limit;
      if (usage.account_type === 'premium') {
        accountUsage.textContent = 'Unlimited this month';
      } else {
        accountUsage.textContent = `${usage.monthly_usage}/${usageLimit} this month`;
      }
      
      // Update usage styling based on usage level
      accountUsage.className = 'usage-text';
      if (usage.account_type === 'free') {
        const usagePercent = usage.monthly_usage / usage.usage_limit;
        if (usagePercent >= 1) {
          accountUsage.className += ' limit-reached';
        } else if (usagePercent >= 0.8) {
          accountUsage.className += ' warning';
        }
      }
      
      accountStatus.style.display = 'block';
      
      // Show auto-analysis settings only for premium users
      if (usage.account_type === 'premium') {
        autoAnalysisSettings.style.display = 'block';
      } else {
        autoAnalysisSettings.style.display = 'none';
      }
      
    } catch (error) {
      console.log('Failed to load account status:', error);
      accountStatus.style.display = 'none';
      autoAnalysisSettings.style.display = 'none';
    }
  }
  
  // Setup auto-analysis settings
  function setupAutoAnalysisSettings() {
    // Load current auto-analysis settings and preferences
    chrome.storage.sync.get([
      'autoAnalysisEnabled',
      'analysisTrigger',
      'analysisDepth', 
      'showIndicator',
      'autoOpenSidebar',
      'quietMode'
    ], (result) => {
      // Main toggle
      const isEnabled = result.autoAnalysisEnabled !== false; // Default to true
      autoAnalysisToggle.checked = isEnabled;
      
      // Show/hide preferences based on toggle state
      updatePreferencesVisibility(isEnabled);
      
      // Load preference values with defaults
      analysisTrigger.value = result.analysisTrigger || 'immediate';
      analysisDepth.value = result.analysisDepth || 'thorough';
      showIndicator.checked = result.showIndicator !== false; // Default to true
      autoOpenSidebar.checked = result.autoOpenSidebar !== false; // Default to true
      quietMode.checked = result.quietMode === true; // Default to false
    });
    
    // Handle main toggle change
    autoAnalysisToggle.addEventListener('change', async (e) => {
      const isEnabled = e.target.checked;
      
      try {
        // Save to storage
        await chrome.storage.sync.set({ autoAnalysisEnabled: isEnabled });
        
        // Update preferences visibility
        updatePreferencesVisibility(isEnabled);
        
        // Update background script
        await updateBackgroundSettings();
        
        console.log(`Auto-analysis ${isEnabled ? 'enabled' : 'disabled'}`);
        
        // Show feedback
        showSettingsFeedback(isEnabled ? 'Auto-analysis enabled' : 'Auto-analysis disabled');
      } catch (error) {
        console.error('Error updating auto-analysis settings:', error);
        // Revert toggle on error
        autoAnalysisToggle.checked = !isEnabled;
      }
    });
    
    // Handle preference changes
    [analysisTrigger, analysisDepth, showIndicator, autoOpenSidebar, quietMode].forEach(element => {
      element.addEventListener('change', async () => {
        try {
          await saveAllAutoAnalysisPreferences();
          await updateBackgroundSettings();
          showSettingsFeedback('Preferences updated');
          console.log('Auto-analysis preferences updated');
        } catch (error) {
          console.error('Error saving preferences:', error);
        }
      });
    });
  }
  
  // Helper function to show/hide preferences section
  function updatePreferencesVisibility(isEnabled) {
    if (autoAnalysisPreferences) {
      autoAnalysisPreferences.style.display = isEnabled ? 'block' : 'none';
    }
  }
  
  // Helper function to save all auto-analysis preferences
  async function saveAllAutoAnalysisPreferences() {
    const preferences = {
      autoAnalysisEnabled: autoAnalysisToggle.checked,
      analysisTrigger: analysisTrigger.value,
      analysisDepth: analysisDepth.value,
      showIndicator: showIndicator.checked,
      autoOpenSidebar: autoOpenSidebar.checked,
      quietMode: quietMode.checked
    };
    
    await chrome.storage.sync.set(preferences);
    return preferences;
  }
  
  // Setup general settings
  function setupGeneralSettings() {
    // Load current general settings
    chrome.storage.sync.get([
      'enableShortcuts',
      'enableNotifications',
      'theme',
      'cacheResults'
    ], (result) => {
      enableShortcuts.checked = result.enableShortcuts !== false; // Default to true
      enableNotifications.checked = result.enableNotifications !== false; // Default to true
      themeSelect.value = result.theme || 'light';
      cacheResults.checked = result.cacheResults !== false; // Default to true
    });
    
    // Handle general settings changes
    [enableShortcuts, enableNotifications, themeSelect, cacheResults].forEach(element => {
      element.addEventListener('change', async () => {
        try {
          await saveAllGeneralSettings();
          showSettingsFeedback('Settings updated');
          console.log('General settings updated');
        } catch (error) {
          console.error('Error saving general settings:', error);
        }
      });
    });
  }
  
  // Helper function to save all general settings
  async function saveAllGeneralSettings() {
    const settings = {
      enableShortcuts: enableShortcuts.checked,
      enableNotifications: enableNotifications.checked,
      theme: themeSelect.value,
      cacheResults: cacheResults.checked
    };
    
    await chrome.storage.sync.set(settings);
    return settings;
  }
  
  // Setup action buttons
  function setupActionButtons() {
    clearCacheBtn.addEventListener('click', async () => {
      if (confirm('Are you sure you want to clear all cached data? This will remove stored analysis results and some preferences.')) {
        try {
          await chrome.storage.local.clear();
          showSettingsFeedback('Cache cleared successfully');
          console.log('Cache cleared');
        } catch (error) {
          console.error('Error clearing cache:', error);
          showSettingsFeedback('Failed to clear cache', 'error');
        }
      }
    });
    
    reportIssueBtn.addEventListener('click', () => {
      // Open issue reporting (could be GitHub issues, support form, etc.)
      const issueUrl = 'https://github.com/idob1212/truth-pilot/issues/new';
      chrome.tabs.create({ url: issueUrl });
    });
    
    contactSupportBtn.addEventListener('click', () => {
      // Open support contact
      const supportUrl = 'mailto:support@truthpilot.com?subject=TruthPilot Extension Support';
      chrome.tabs.create({ url: supportUrl });
    });
  }
  
  // Load version information
  function loadVersionInfo() {
    const manifest = chrome.runtime.getManifest();
    versionInfo.textContent = `v${manifest.version}`;
  }
  
  // Helper function to update background script with all settings
  async function updateBackgroundSettings() {
    return chrome.runtime.sendMessage({
      action: 'updateAutoAnalysisSettings'
    });
  }
  
  // Show settings feedback
  function showSettingsFeedback(message, type = 'success') {
    // Create temporary status message
    const statusMsg = document.createElement('div');
    statusMsg.className = `settings-feedback ${type}`;
    statusMsg.textContent = message;
    statusMsg.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: ${type === 'success' ? '#10b981' : '#ef4444'};
      color: white;
      padding: 12px 16px;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 600;
      z-index: 1000;
      opacity: 0;
      transform: translateY(-10px);
      transition: all 0.3s ease;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    `;
    
    document.body.appendChild(statusMsg);
    
    // Animate in
    setTimeout(() => {
      statusMsg.style.opacity = '1';
      statusMsg.style.transform = 'translateY(0)';
    }, 10);
    
    // Remove after 3 seconds
    setTimeout(() => {
      statusMsg.style.opacity = '0';
      statusMsg.style.transform = 'translateY(-10px)';
      setTimeout(() => {
        if (statusMsg.parentNode) {
          statusMsg.parentNode.removeChild(statusMsg);
        }
      }, 300);
    }, 3000);
  }
  
  // Setup debug panel
  function setupDebugPanel() {
    // Show debug panel only in development mode
    if (config.isDevelopment()) {
      debugPanel.style.display = 'block';
      updateDebugInfo();
    }
    
    // Test auto-analysis button
    testAutoAnalysis.addEventListener('click', () => {
      chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, {
          action: 'triggerAutoAnalysis'
        }, (response) => {
          console.log('🧪 Test auto-analysis response:', response);
          updateDebugInfo();
        });
      });
    });
  }
  
  // Update debug information
  function updateDebugInfo() {
    chrome.storage.sync.get(['autoAnalysisEnabled', 'userAccountType'], (result) => {
      chrome.runtime.sendMessage({
        action: 'requestAuthVerification'
      }, (authResponse) => {
        const debugHTML = `
          <p><strong>🔧 Extension Environment:</strong> ${config.ENVIRONMENT}</p>
          <p><strong>📦 Auto-Analysis Enabled:</strong> ${result.autoAnalysisEnabled}</p>
          <p><strong>👤 User Account Type:</strong> ${result.userAccountType || 'unknown'}</p>
          <p><strong>🔐 Authentication Status:</strong> ${authResponse?.settings?.isAuthenticated ? 'authenticated' : 'not authenticated'}</p>
          <p><strong>🌐 API URL:</strong> ${config.getApiUrl()}</p>
          <p><strong>📄 Current URL:</strong> ${window.location.href}</p>
        `;
        debugInfo.innerHTML = debugHTML;
      });
    });
  }
});