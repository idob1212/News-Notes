# TruthPilot Extension - Production Setup Guide

This guide explains how to prepare the TruthPilot extension for production deployment with OAuth authentication.

## Prerequisites

Before deploying to production, you need to:

1. **Google OAuth Setup**
   - Create a Google Cloud Project
   - Enable Google+ API and Google Identity Service
   - Create OAuth 2.0 credentials (Client ID)
   - Configure authorized redirect URIs

2. **Apple OAuth Setup** (Optional)
   - Register with Apple Developer Program
   - Create an App ID and Services ID
   - Configure Sign in with Apple

3. **Production Backend**
   - Deploy your backend to a production service (Render, Heroku, etc.)
   - Update environment variables with OAuth secrets
   - Verify CORS settings allow extension origins

## Configuration Steps

### 1. Update Manifest.json

Replace the placeholder Google Client ID in `manifest.json`:

```json
"oauth2": {
  "client_id": "YOUR_ACTUAL_GOOGLE_CLIENT_ID.apps.googleusercontent.com",
  "scopes": ["openid", "email", "profile"]
}
```

### 2. Update Account.js

Replace the Apple Client ID placeholder in `account.js`:

```javascript
appleAuthUrl.searchParams.set('client_id', 'YOUR_ACTUAL_APPLE_CLIENT_ID');
```

### 3. Update API URLs

Verify that all configuration files point to your production API:

- `background.js`: Update `API_BASE_URL` in production environment
- `sidebar.js`: Update `API_BASE_URL` in production environment  
- `account.js`: Update `API_BASE_URL` in production environment

### 4. Switch to Production Mode

Use the environment switcher to set all files to production mode:

```bash
node switch-env.js prod
```

This will:
- Update all ENVIRONMENT variables to 'production'
- Validate OAuth configuration
- Show a production readiness checklist

## OAuth Flow Details

### Google Sign-In (Production)
- Uses Chrome Identity API (`chrome.identity.getAuthToken`)
- Automatic token refresh
- Proper error handling and fallbacks

### Apple Sign-In (Production)
- Uses `chrome.identity.launchWebAuthFlow`
- Web-based OAuth flow (Apple doesn't provide direct extension API)
- Extracts ID token from redirect URL

### Development Mode
- Both OAuth providers use dummy tokens for testing
- No external API calls required
- Simulates successful authentication flows

## Testing Checklist

Before deploying:

- [ ] Google OAuth Client ID configured
- [ ] Apple OAuth Client ID configured (if using Apple Sign-In)
- [ ] Production API URLs updated
- [ ] Backend OAuth endpoints working
- [ ] Extension tested with production backend
- [ ] OAuth flows tested with real providers
- [ ] Token refresh working correctly
- [ ] Error handling tested

## Security Considerations

1. **Client IDs**: Ensure OAuth client IDs are correctly configured
2. **Redirect URIs**: Verify redirect URIs match extension ID
3. **Token Storage**: Tokens are stored securely using Chrome storage API
4. **Token Refresh**: Automatic refresh prevents expired token issues
5. **Error Handling**: Graceful fallbacks for OAuth failures

## Troubleshooting

### Common Issues

1. **"Chrome Identity API not available"**
   - Ensure `identity` permission is in manifest.json
   - Check that OAuth2 configuration is present

2. **"Invalid Google token"**
   - Verify Client ID is correct
   - Check redirect URIs in Google Console
   - Ensure scopes match backend expectations

3. **Apple Sign-In not working**
   - Verify Apple Client ID is set
   - Check Apple Developer Console configuration
   - Ensure redirect URI is whitelisted

### Development vs Production

The extension automatically detects the environment mode and:
- **Development**: Uses dummy tokens for testing
- **Production**: Uses real OAuth flows with Chrome Identity API

## Environment Switching

Use the provided script to switch between environments:

```bash
# Switch to development
node switch-env.js dev

# Switch to production  
node switch-env.js prod
```

The script will validate configuration and show warnings for missing OAuth setup. 